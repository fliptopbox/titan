
import tree from "./tree.js";
import bramble from "./bramble.js";
import sand from "./sand.js";
import bog from "./bog.js";
import drift from "./drift.js";
import volcano from "./volcano.js";

export default { tree, bramble, sand, bog, drift, volcano };
